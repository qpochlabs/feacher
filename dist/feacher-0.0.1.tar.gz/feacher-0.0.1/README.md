<div style="margin:0 auto;"><img src="https://github.com/qpochlabs/feacher/blob/main/assets/logo.png" width="85"/></div>

# Feacher
Feacher is a light-weight Image feature extraction library that can help in transfer learning applications.
